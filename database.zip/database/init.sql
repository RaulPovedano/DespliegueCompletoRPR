CREATE TABLE secretosRPR (
 id INT AUTO_INCREMENT PRIMARY KEY,
 fraseRPR VARCHAR(255) NOT NULL
);
INSERT INTO secretosRPR (fraseRPR) VALUES ('La base de datos responde, buenos días Raul Povedano Ruiz');
