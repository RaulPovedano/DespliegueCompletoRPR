# DespliegueCompletoRPR


- BACKEND: Symfony
- FRONTEND: React
- BASE DE DATOS: SQL

## Raul Povedano Ruiz